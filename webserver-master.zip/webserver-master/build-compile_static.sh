g++ -I include -L lib -g main.cpp -w -static-libstdc++ -static-libgcc -lpthread -fpermissive -o webserverCpp

